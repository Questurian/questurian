# Feature Patterns Catalog

Example directory structures for feature-based organization across different project types. Adapt these to match existing project conventions.

## Contents
- React / Frontend SPA
- Backend API Service (Node/Bun)
- Backend API Service (Python)
- Backend API Service (Go)
- Full-Stack Monorepo
- Mobile (React Native)

---

## React / Frontend SPA

```
src/
├── app/                    # Bootstrap, routing, providers
│   ├── routes.tsx
│   ├── providers.tsx
│   └── App.tsx
├── features/
│   ├── auth/
│   │   ├── components/     # Auth-specific components
│   │   ├── hooks/          # useAuth, useSession
│   │   ├── api/            # Auth API calls
│   │   ├── types.ts
│   │   ├── utils.ts
│   │   └── index.ts        # Public API (barrel export)
│   ├── dashboard/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── api/
│   │   ├── types.ts
│   │   └── index.ts
│   └── settings/
│       ├── components/
│       ├── hooks/
│       ├── api/
│       ├── types.ts
│       └── index.ts
├── shared/
│   ├── components/         # Button, Modal, Layout, etc.
│   ├── hooks/              # useDebounce, useLocalStorage
│   ├── utils/              # formatDate, cn, etc.
│   ├── types/              # Global types
│   └── api/                # API client, interceptors
└── index.tsx
```

**Key conventions:**
- Each feature exports via `index.ts` barrel file
- `app/` wires features together through routing and providers
- `shared/` contains only framework-agnostic or truly reusable code
- Feature-internal components are not exported from `index.ts`

---

## Backend API Service (Node/Bun)

```
src/
├── features/
│   ├── users/
│   │   ├── users.routes.ts
│   │   ├── users.service.ts
│   │   ├── users.repository.ts
│   │   ├── users.types.ts
│   │   ├── users.validation.ts
│   │   └── index.ts
│   ├── orders/
│   │   ├── orders.routes.ts
│   │   ├── orders.service.ts
│   │   ├── orders.repository.ts
│   │   ├── orders.types.ts
│   │   ├── orders.validation.ts
│   │   └── index.ts
│   └── notifications/
│       ├── notifications.routes.ts
│       ├── notifications.service.ts
│       ├── notifications.types.ts
│       └── index.ts
├── shared/
│   ├── middleware/          # Auth, error handling, logging
│   ├── database/           # Connection, migrations, query helpers
│   ├── utils/              # Shared utilities
│   └── types/              # Global types, error types
├── app.ts                  # Server setup, middleware registration
└── index.ts                # Entry point
```

**Key conventions:**
- Files prefixed with feature name for clarity when searching
- `routes → service → repository` layering within each feature
- Database access only through repository files
- Shared middleware applies across features

---

## Backend API Service (Python)

```
src/
├── features/
│   ├── users/
│   │   ├── __init__.py
│   │   ├── router.py       # Endpoint definitions
│   │   ├── service.py      # Business logic
│   │   ├── repository.py   # Data access
│   │   ├── schemas.py      # Pydantic models
│   │   ├── models.py       # ORM models
│   │   └── dependencies.py # DI for this feature
│   ├── orders/
│   │   ├── __init__.py
│   │   ├── router.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   ├── schemas.py
│   │   └── models.py
│   └── payments/
│       └── ...
├── shared/
│   ├── database.py         # Engine, session factory
│   ├── middleware.py        # Auth, CORS, error handling
│   ├── schemas.py          # Shared response models
│   └── utils.py
├── main.py                 # App factory, router registration
└── config.py               # Settings
```

---

## Backend API Service (Go)

```
internal/
├── features/
│   ├── users/
│   │   ├── handler.go      # HTTP handlers
│   │   ├── service.go      # Business logic
│   │   ├── repository.go   # Data access
│   │   ├── model.go        # Domain types
│   │   └── routes.go       # Route registration
│   ├── orders/
│   │   ├── handler.go
│   │   ├── service.go
│   │   ├── repository.go
│   │   ├── model.go
│   │   └── routes.go
│   └── auth/
│       └── ...
├── shared/
│   ├── middleware/
│   ├── database/
│   └── errors/
cmd/
├── server/
│   └── main.go             # Entry point
└── migrate/
    └── main.go
```

---

## Full-Stack Monorepo

```
packages/
├── client/                 # Frontend (uses feature structure above)
│   └── src/
│       ├── app/
│       ├── features/
│       └── shared/
├── server/                 # Backend (uses feature structure above)
│   └── src/
│       ├── features/
│       └── shared/
├── shared/                 # Cross-package shared code
│   └── src/
│       ├── types/          # Shared types between client and server
│       ├── validation/     # Shared validation schemas
│       └── constants/
└── package.json            # Workspace configuration
```

**Key conventions:**
- Each package is independently buildable
- `packages/shared/` contains only types, validation, and constants shared between client and server
- Feature boundaries exist within each package independently

---

## Mobile (React Native)

```
src/
├── app/
│   ├── navigation/         # Stack/tab navigators
│   └── providers/
├── features/
│   ├── auth/
│   │   ├── screens/        # LoginScreen, RegisterScreen
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── api/
│   │   ├── types.ts
│   │   └── index.ts
│   ├── feed/
│   │   ├── screens/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── index.ts
│   └── profile/
│       └── ...
├── shared/
│   ├── components/         # Themed primitives
│   ├── hooks/
│   ├── theme/
│   └── utils/
└── index.ts
```

---

## Naming Conventions Summary

| Project Type | Feature Files | Barrel Export |
|---|---|---|
| React frontend | `components/`, `hooks/`, `api/`, `types.ts` | `index.ts` |
| Node/Bun API | `[feature].routes.ts`, `[feature].service.ts` | `index.ts` |
| Python API | `router.py`, `service.py`, `schemas.py` | `__init__.py` |
| Go API | `handler.go`, `service.go`, `repository.go` | package-level |

Adapt file naming to match whatever convention the existing codebase uses. Consistency within the project matters more than matching these examples exactly.
