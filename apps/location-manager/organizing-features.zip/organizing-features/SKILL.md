---
name: organizing-features
description: Organizes codebases using feature-based architecture. This skill should be used when refactoring an existing codebase from flat or layer-based structure to feature-based organization, or when scaffolding a new feature in a project. Applies to any framework or language.
---

# Feature-Based Organization

Group code by domain feature rather than by technical layer. Each feature is a self-contained directory owning its related components, logic, types, and tests.

## Workflow Decision Tree

Determine the task type:

- **Refactoring existing codebase** → Follow "Refactoring Workflow"
- **Adding a new feature** → Follow "New Feature Workflow"

---

## Refactoring Workflow

### Step 1: Analyze Current Structure

1. Map the existing directory structure
2. Identify the current pattern (flat, layer-based, mixed)
3. Identify logical features by analyzing:
   - Route/page groupings
   - Import clusters (files that import each other frequently)
   - Naming patterns (e.g., `UserList`, `UserService`, `userTypes` → `users` feature)
4. Identify shared/cross-cutting code (utilities, middleware, base components)

### Step 2: Create Migration Plan

Before making any changes, produce a plan for user approval:

```
Migration Plan:
- [ ] Identified features: [list]
- [ ] Proposed structure: [tree]
- [ ] File moves: [current → new for each file]
- [ ] Shared code: [what stays in shared/]
- [ ] Import updates: [affected paths]
```

Include the proposed directory tree. See [references/feature_patterns_catalog.md](references/feature_patterns_catalog.md) for structures matching the project's stack.

Present the plan and wait for approval before proceeding.

### Step 3: Execute Migration

Migrate one feature at a time:

1. Create the feature directory
2. Move related files into it
3. Update all import paths referencing moved files
4. Add a barrel export (`index.ts`, `__init__.py`, etc.) if the project uses them
5. Verify the project builds/lints/passes tests
6. Commit the migrated feature

Repeat for each feature. Move shared/cross-cutting code to `shared/` last.

---

## New Feature Workflow

### Step 1: Identify Feature Boundaries

- Determine feature name and scope
- Check existing features for structural conventions to mirror
- Identify which shared code the feature will consume

### Step 2: Scaffold Feature Directory

Mirror the structure of existing features in the project. Only create subdirectories that will actually be used.

Example (adapt to project conventions):
```
features/[feature-name]/
├── components/
├── hooks/
├── api/
├── types.ts
└── index.ts
```

See [references/feature_patterns_catalog.md](references/feature_patterns_catalog.md) for framework-specific patterns.

### Step 3: Implement

1. Start with types/interfaces defining the feature's domain
2. Build inside-out: data layer → logic → presentation
3. Import from `shared/` for cross-cutting concerns
4. Export only the public API through the barrel file

Register the feature in routing, navigation, or configuration as needed.

---

## Boundary Guidelines

**Recommended boundaries** (enforce pragmatically, not dogmatically):

- Features should not import directly from other features
- Cross-feature communication goes through shared code, events, or a parent orchestrator
- Shared code lives in a dedicated `shared/` or `common/` directory
- Shared code should not import from features

**When cross-feature imports are acceptable:**

- Temporarily during incremental migration
- When two features are tightly coupled and merging them would be worse
- When the import is for a type/interface only, not implementation

Document intentional boundary violations with a comment explaining why.

## Pattern Catalog

See [references/feature_patterns_catalog.md](references/feature_patterns_catalog.md) for example directory structures for:

- React / frontend SPA
- Backend API services (Node/Bun, Python, Go)
- Full-stack monorepos
- Mobile applications
